/*
 * File: Place99Beepers.java
 * ----------------------------
 * This demo shows you how to repeat commands a fixed
 * number of times.
 */
import stanford.karel.*;

public class Place99Beepers extends SuperKarel {
	
	/**
	 * Method: Run
	 * ------------------
	 * Program execution starts here.
	 */
	public void run() {
		// your code here
	}
}
