/*
 * File: RhoombaKarel.java
 * ------------------------
 * Karel clears all beepers in a world
 */

import stanford.karel.SuperKarel;

public class RhoombaKarel extends SuperKarel {

	public void run() {
		
	}




}
